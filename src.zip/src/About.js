import React from 'react';
import './About.css';
import { RiUserSearchFill } from "react-icons/ri";
export default function About(){
    return(
        <>

    <main class='main'>
        <section class="about-us">
            <h2>About Us</h2>
            <p>Welcome to Winter goods, your number one source for all things clothes for this winter. We're dedicated to providing you the best of product, with a focus on dependability, customer service, and unique selling point.</p>
            <p>Founded in 2023 by Poojitha, Winter goods has come a long way from its beginnings in Nellore. When Poojitha first started out, her passion drove them to start their own business.</p>
            <p>We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.</p>
            <p><u><strong>Sincerely</strong></u><br/>The Winter goods Team</p>
        </section>

        <section class="team">
            <h2 ><RiUserSearchFill fontSize={60}/></h2>

        </section>
    </main>

    <footer>
        <p>&copy; 2024 Winter Goods. All rights reserved.</p>
    </footer>
        </>
    );
}