import logo from './logo.svg';
import Home from  './Home';
import About from './About'
import Shop from './Shop'
import Contact from './Contact';
import Login from './Login';
import Header from './Header';
import Footer from './Footer';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Cart1 from './Cart1';
function App() {
  return (
    <Router>
            <Header />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/shop" element={<Shop />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/login" element={<Login />} />
                <Route path="/home" element={<Home/>}/>
                <Route path="/shopNow" element={<Shop/>}/>
                <Route path="/cart" element={<Cart1/>}/>
            </Routes>
            <Footer />
        </Router>

);

}

export default App;
