import React from "react";
import './contact.css'
import { FaPhoneVolume } from "react-icons/fa6";
import { MdEmail } from "react-icons/md";
export default function Contact(){
    return(
        <>
    <main class="contact-us">
        <section class="contact-us">
            <h2><u>Contact Us</u></h2>
            <h1><FaPhoneVolume /> (+121)-90876-89076</h1>
            <h1><MdEmail />  wintergoods@gmail.com</h1>
        </section>
    </main>
        </>
    );
}