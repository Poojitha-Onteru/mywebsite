import React from 'react';
import './footer.css'
const Footer = () => {
    return (
        <footer class='ftr'>
            <p>&copy; 2024 Winter Goods. All rights reserved.</p>
        </footer>
    );
};

export default Footer;