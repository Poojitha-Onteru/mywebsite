import React from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingBag } from "react-icons/fa";
import './header.css'
import { TiHome } from "react-icons/ti";
import { IoCart } from "react-icons/io5";
import { FaUsersLine } from "react-icons/fa6";
import { RiCustomerServiceFill } from "react-icons/ri";
import { IoLogInOutline } from "react-icons/io5";


const Header = () => {
    return (
        <header class="hdr">
            <div className="logo">
                <h1><FaShoppingBag />  WINTER GOODs</h1>
            </div>
            <nav>
                <ul>
                    <li><Link to="/"><TiHome fontSize={15} />Home</Link></li>
                    <li><Link to="/shop"><IoCart fontSize={15}/>Shop</Link></li>
                    <li><Link to="/about"><FaUsersLine fontSize={17} />About</Link></li>
                    <li><Link to="/contact"><RiCustomerServiceFill fontSize={15}/>Contact</Link></li>
                    <li><Link to="/login"><IoLogInOutline fontSize={15} />Login</Link></li>
                </ul>
            </nav>
        </header>
    );
};

export default Header;
