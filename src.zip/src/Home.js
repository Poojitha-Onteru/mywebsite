import React from 'react'
import './home.css'
import img3 from './boots.jpeg'
import img1 from './hats.jpeg'
import img2 from './sweater.jpeg'
import { Link } from 'react-router-dom'
import { IoStarSharp } from "react-icons/io5";
import { FaBasketShopping } from "react-icons/fa6";
export default function Home(){
    return(
        <>
    <main class='main'>
        <section class="hero">
            <h1><IoStarSharp color='gold' class='star'/>Welcome to Winter goods</h1>
            <p>Your one-stop shop for winter needs!<br/>Quality is out policy</p>
            
            <Link to='/shopNow'>
            <button class="btn2"><FaBasketShopping />Shop Now</button></Link>
        </section>

        <section class="login">
            <p><strong>Login before you continue shopping...</strong></p>
            <Link to='/login'>
            <button  class="btn">Login</button></Link>
        </section>

        <section class="categories">
            <h2>Available Products...</h2>
            <div class="category-list">
                <div class="category">
                    <img src={img1}/>
                    <h3>Hats</h3>
                </div>
                <div class="category">
                    <img src={img2}/>
                    <h3>sweaters</h3>
                </div>
                <div class="category">
                    <img src={img3}/>
                    <h3>Boots</h3>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Winter Goods. All rights reserved.</p>
    </footer>
        </>
    );
}
