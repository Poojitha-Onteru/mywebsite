import React, { useState } from 'react';
import './boot.css'
import { RiLockPasswordFill } from "react-icons/ri";
import { FaUser } from "react-icons/fa";
import './login.css'
import { Link } from 'react-router-dom';

const Login = () => {
  /*const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === 'admin' && password === 'password') {
      onLogin(true);
    } else {
      setError('Invalid username or password');
    }
  };*/

  return (
    <form class='login'>
        <h1>LOGIN</h1>
        <fieldset class='fset'>
            <div data-mdb-input-init class="user">
                <label class="form-label" for="form3Example3c"><FaUser fontSize={20} /></label>
                <input  placeholder="Enter user id" type="email" id="form3Example3c" class="form-control" />
            </div>
            <br/>
            <div data-mdb-input-init class="form-outline flex-fill mb-0">
                <label htmlFor='textArea' class="form-label" for="form3Example3c"><RiLockPasswordFill fontSize={30} class='icon' /></label>
                <input placeholder='Enter password' type="email" id="form3Example3c" class="password" />
            </div>
            <br/>
            <Link to='/home'>
            <button  type="button">LOGIN</button></Link>
        </fieldset>
    </form>
  );
};

export default Login;
