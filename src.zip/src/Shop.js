import React from 'react';
import b1 from './boot1.jpeg'
import b2 from './boot2.jpeg'
import b3 from './boots.jpeg'
import b4 from './b4.jpeg'
import b6 from './b6.jpeg'
import img1 from './img1.jpeg'
import img2 from './img2.jpeg'
import img3 from './img3.jpeg'
import img4 from './img4.jpeg'
import s1 from './s1.jpeg'
import s2 from './s2.jpeg'
import s3 from './s3.jpeg'
import s4 from './s4.jpeg'
import s5 from './s5.jpeg'
import './shop.css'
export default function Shop(){
    return(
        <>
        <div id="shop" class="content">
    <h1 class='shop'>Shop</h1>
    <div>
    <div class="product">
        <h3>Quilted mild winter boots</h3>
        <img src={b1} alt="Mariah"/>
        <p>Rs.1000</p>
        <button onclick="addToCart('Product 1', 1,000)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>Cashmeere boots</h3>
        <img src={b2} alt="Cashmeere boots"/>
        <p>Rs.2,500</p>
        <button onclick="addToCart('Product 2', 2,500)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>Mariah winter boots</h3>
        <img src={b3} alt="Mariah"/>
        <p>Rs.1,500</p>
        <button onclick="addToCart('Product 3', 1,500)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>snow boots</h3>
        <img src={b4} alt="Mariah"/>
        <p>Rs.2,000</p>
        <button onclick="addToCart('Product 3', 2,000)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>snow boots</h3>
        <img src={b6} alt="Mariah"/>
        <p>Rs.500</p>
        <button onclick="addToCart('Product 3', 500)">Add to Cart</button>
    </div>
    </div>
    <div>
    <div class="product">
        <h3>Mariah hats</h3>
        <img src={img1} alt="Mariah"/>
        <p>Rs.3,999</p>
        <button onclick="addToCart('Product 3', 3,999)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>Mariah hats</h3>
        <img src={img2} alt="Mariah"/>
        <p>Rs.3,099</p>
        <button onclick="addToCart('Product 3', 3099)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>woolen hats</h3>
        <img src={img3} alt="Mariah"/>
        <p>Rs.3,500</p>
        <button onclick="addToCart('Product 3', 3,500)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>Mariah hats</h3>
        <img src={img4} alt="Mariah"/>
        <p>Rs.500</p>
        <button onclick="addToCart('Product 3', 500)">Add to Cart</button>
    </div>
    </div>
    <div>
    <div class="product">
        <h3>woolen sweaters</h3>
        <img src={s1} alt="Mariah"/>
        <p>Rs.670</p>
        <button onclick="addToCart('Product 3', 670)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>sweater</h3>
        <img src={s2} alt="Mariah"/>
        <p>Rs.700</p>
        <button onclick="addToCart('Product 3', 700)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>sweater</h3>
        <img src={s3} alt="Mariah"/>
        <p>Rs.2,500</p>
        <button onclick="addToCart('Product 3', 2,500)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>sweater</h3>
        <img src={s4} alt="Mariah"/>
        <p>Rs.1,000</p>
        <button onclick="addToCart('Product 3', 1,000)">Add to Cart</button>
    </div>
    <div class="product">
        <h3>sweater</h3>
        <img src={s5} alt="Mariah"/>
        <p>Rs.1,500</p>
        <button onclick="addToCart('Product 3', 1,500)">Add to Cart</button>
    </div>

    </div>



</div>

        </>
    );
}